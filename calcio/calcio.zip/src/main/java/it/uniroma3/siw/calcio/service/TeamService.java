package it.uniroma3.siw.calcio.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.calcio.exception.DuplicateTeamException;
import it.uniroma3.siw.calcio.model.Match;
import it.uniroma3.siw.calcio.model.Player;
import it.uniroma3.siw.calcio.model.Team;
import it.uniroma3.siw.calcio.model.Tournament;
import it.uniroma3.siw.calcio.repository.MatchRepository;
import it.uniroma3.siw.calcio.repository.PlayerRepository;
import it.uniroma3.siw.calcio.repository.TeamRepository;
import it.uniroma3.siw.calcio.repository.TournamentRepository;

@Service
public class TeamService {

    private final TeamRepository teamRepository;
    private final MatchRepository matchRepository;
    private final PlayerRepository playerRepository;
    private final TournamentRepository tournamentRepository;

    public TeamService(TeamRepository teamRepository, MatchRepository matchRepository,
            PlayerRepository playerRepository,
            TournamentRepository tournamentRepository) {
        this.teamRepository = teamRepository;
        this.matchRepository = matchRepository;
        this.playerRepository = playerRepository;
        this.tournamentRepository = tournamentRepository;
    }

    @Transactional(readOnly = true)
    public List<Team> findAll() {
        return this.teamRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<Team> findById(Long id) {
        Optional<Team> teamOpt = this.teamRepository.findById(id);
        if (teamOpt.isPresent()) {
            Team team = teamOpt.get();
            if (team.getPlayers() != null)
                team.getPlayers().size();
            if (team.getHomeMatches() != null)
                team.getHomeMatches().size();
            if (team.getAwayMatches() != null)
                team.getAwayMatches().size();
            if (team.getTournaments() != null) // AGGIUNTO DA ME
                team.getTournaments().size();
        }
        return teamOpt;
    }

    @Transactional(readOnly = true)
    public Optional<Team> findByIdWithPlayers(Long id) {
        Optional<Team> teamOpt = this.teamRepository.findByIdWithPlayers(id);
        if (teamOpt.isPresent()) {
            Team team = teamOpt.get();
            // IMPORTANTE: Poiché in JPA/Hibernate non possiamo fare il fetch simultaneo di più collezioni di tipo List
            // (come players, homeMatches, awayMatches) altrimenti scateniamo una MultipleBagFetchException,
            // usiamo un approccio ibrido: 'players' viene caricato con @EntityGraph nella query SQL principale,
            // mentre 'homeMatches', 'awayMatches' e 'tournaments' vengono caricati lazy qui, invocando .size() 
            // finché la transazione è ancora aperta grazie a @Transactional.
            if (team.getHomeMatches() != null)
                team.getHomeMatches().size();
            if (team.getAwayMatches() != null)
                team.getAwayMatches().size();
            if (team.getTournaments() != null)
                team.getTournaments().size();
        }
        return teamOpt;
    }

    @Transactional
    public Team save(Team team) throws DuplicateTeamException {
        boolean duplicate = team.getId() == null
                ? this.teamRepository.existsByNameAndYearFoundation(team.getName(), team.getYearFoundation())
                : this.teamRepository.existsByNameAndYearFoundationAndIdNot(team.getName(), team.getYearFoundation(),
                        team.getId());
        if (duplicate) {
            throw new DuplicateTeamException(team.getName(), team.getYearFoundation());
        }
        return this.teamRepository.save(team);
    }

    @Transactional
    public void deleteById(Long id) {
        Optional<Team> teamOpt = this.teamRepository.findById(id);
        if (teamOpt.isPresent()) {
            Team team = teamOpt.get();

            // 1. Rimuovi la squadra dai tornei
            for (Tournament t : team.getTournaments()) {
                t.getTeams().remove(team);
                tournamentRepository.save(t);
            }

            // 2. Eliminiamo i giocatori
            for (Player p : team.getPlayers()) {
                p.setTeam(null);
                playerRepository.save(p);
            }

            // 3. Eliminiamo tutte le partite giocate da questa squadra
            List<Match> matchesH = matchRepository.findByHomeTeam(team);
            matchRepository.deleteAll(matchesH);
            List<Match> matchesA = matchRepository.findByAwayTeam(team);
            matchRepository.deleteAll(matchesA);

            // 4. Infine eliminiamo la squadra
            this.teamRepository.delete(team);
        }
    }
}